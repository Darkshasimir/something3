
#include "maxprotein.hh"

int main() {
  return 0;
}
