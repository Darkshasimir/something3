# Project 2: greedy versus exhaustive

Group members:

Ada Lovelace adalovelace@csu.fullerton.edu

Charles Babbage charlesbab@csu.fullerton.edu
